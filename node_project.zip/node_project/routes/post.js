const express = require('express');
const router = express.Router();

router.get('/', (req,res) => {
    res.send("Welcome to User's Section");
});

router.get('/post', (req,res) => {
    res.send("Welcome to user's  Login Section");
});

module.exports = router;
