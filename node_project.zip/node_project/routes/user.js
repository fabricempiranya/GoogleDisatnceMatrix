const express = require('express');
const router = express.Router();
const User = require('../models/user');

router.get('/', (req,res) => {
    res.send("Welcome to User's Section");
});

router.post('/create', async(req,res) => {
    try {
        const user = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            password: req.body.password,
            address: req.body.address
        };
        const savedUser = await User.create(user);
        if (savedUser) return res.status(200).send("User created Successfully");
        return res.status(400).send("Check your inputs");
    } catch (error) {
        console.log(error);
        return res.status(500).send("Internal Server error");
    }
});

router.get('/all', async(req,res) => {
    try {
        const users = await User.find();
        if (users) return res.status(200).json({users: users});
        return res.status(400).send("Invalid request")
    } catch (error) {
        return res.status(500).send("Bad request");
    }
})
module.exports = router;